<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\DELL\Documents\FireSfaty\syst\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>