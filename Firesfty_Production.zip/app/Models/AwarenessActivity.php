<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AwarenessActivity extends Model
{
    use HasFactory;

    protected $fillable = [
        'activity_name',
        'location',
        'activity_date',
        'beneficiaries_count',
        'description',
    ];
}
